from django.contrib import admin
from core.erp.models import *

# Register your models here.
admin.site.register(Category)